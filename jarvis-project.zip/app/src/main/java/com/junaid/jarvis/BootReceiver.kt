package com.junaid.jarvis

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action == Intent.ACTION_BOOT_COMPLETED || i.action == "android.intent.action.QUICKBOOT_POWERON") {
            if (Prefs.enabled(c)) c.startForegroundService(Intent(c, JarvisService::class.java))
        }
    }
}
