package com.junaid.jarvis

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import org.vosk.android.StorageService
import java.util.Locale

class JarvisService : Service(), RecognitionListener {
    private var model: Model? = null
    private var speech: SpeechService? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private lateinit var commands: CommandHandler
    private val main = Handler(Looper.getMainLooper())

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int = START_STICKY

    override fun onCreate() {
        super.onCreate()
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("jarvis", "Jarvis", NotificationManager.IMPORTANCE_LOW))
        startForeground(1, notification("Loading voice model..."))
        commands = CommandHandler(this) { speak(it) }
        tts = TextToSpeech(this) { st ->
            if (st == TextToSpeech.SUCCESS) {
                tts?.language = Locale("en", "IN")
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) {}
                    override fun onDone(id: String?) { main.post { speech?.setPause(false) } }
                    override fun onError(id: String?) { main.post { speech?.setPause(false) } }
                })
                ttsReady = true
            }
        }
        StorageService.unpack(this, "model", "model",
            { m: Model -> model = m; startListening() },
            { e: java.io.IOException -> update("Voice model error: ${e.message}") })
    }

    private fun startListening() {
        try {
            val rec = Recognizer(model, 16000.0f)
            speech = SpeechService(rec, 16000.0f)
            speech?.startListening(this)
            update("Listening. Say: Jarvis, open YouTube")
        } catch (e: Exception) {
            update("Mic error: ${e.message}")
        }
    }

    private fun speak(t: String) {
        if (!ttsReady) return
        speech?.setPause(true)
        tts?.speak(t, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
    }

    private fun notification(text: String): Notification =
        Notification.Builder(this, "jarvis")
            .setContentTitle("Jarvis")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), 0))
            .build()

    private fun update(text: String) {
        getSystemService(NotificationManager::class.java).notify(1, notification(text))
    }

    override fun onResult(h: String?) {
        val t = try { JSONObject(h ?: "{}").optString("text") } catch (e: Exception) { "" }
        if (t.isNotBlank()) commands.handle(t)
    }
    override fun onPartialResult(h: String?) {}
    override fun onFinalResult(h: String?) {}
    override fun onError(e: Exception?) { update("Error: ${e?.message}") }
    override fun onTimeout() {}

    override fun onDestroy() {
        speech?.stop(); speech?.shutdown()
        tts?.shutdown(); model?.close()
        super.onDestroy()
    }
}
