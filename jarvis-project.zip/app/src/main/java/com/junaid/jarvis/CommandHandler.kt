package com.junaid.jarvis

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.BatteryManager
import android.content.IntentFilter
import android.provider.ContactsContract
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class CommandHandler(private val ctx: Context, private val say: (String) -> Unit) {

    // Agar "Jarvis" sahi pehchana na jaye to yahan aur galat spellings add karein.
    private val wakeWords = listOf("jarvis", "jarvish", "jarves", "jervis", "travis", "jarvas")
    private val digits = mapOf(
        "zero" to "0", "oh" to "0", "one" to "1", "two" to "2", "three" to "3", "four" to "4",
        "five" to "5", "six" to "6", "seven" to "7", "eight" to "8", "nine" to "9"
    )

    fun handle(raw: String) {
        val text = raw.lowercase(Locale.ROOT).trim()
        val w = wakeWords.firstOrNull { text.contains(it) }
        val cmd = (if (w != null) text.substringAfter(w) else text).trim()
        // Wake word na pehchana jaye to bhi seedhe hukum (open, call, ...) maan lo.
        val verbs = Regex("^(open|call|search|google|youtube|play|message|text|send|whatsapp|remember|battery|what time|what is the time|what do you remember)\\b")
        if (w == null && !verbs.containsMatchIn(cmd)) return
        if (cmd.isEmpty()) { say("Yes, I am listening"); return }
        when {
            cmd.startsWith("remember") -> {
                val n = cmd.removePrefix("remember").trim().removePrefix("that").trim()
                if (n.isEmpty()) say("What should I remember?")
                else { Prefs.addNote(ctx, n); say("Okay, I will remember that") }
            }
            cmd.contains("what do you remember") || cmd.contains("my notes") -> {
                val l = Prefs.notes(ctx)
                say(if (l.isEmpty()) "You have no saved notes" else "Your notes. " + l.joinToString(". "))
            }
            Regex("\\btime\\b").containsMatchIn(cmd) ->
                say("It is " + SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date()))
            Regex("\\b(date|today)\\b").containsMatchIn(cmd) ->
                say("Today is " + SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(Date()))
            cmd.contains("battery") -> battery()
            cmd.startsWith("call") -> call(cmd.removePrefix("call").trim())
            Regex("^(send|message|text|whatsapp)\\b").containsMatchIn(cmd) -> message(cmd)
            cmd.startsWith("open") -> openApp(cmd.removePrefix("open").trim())
            cmd.startsWith("youtube") || cmd.startsWith("play") -> {
                val q = cmd.removePrefix("youtube").removePrefix("play").trim()
                say("Searching YouTube for $q")
                view("https://m.youtube.com/results?search_query=" + Uri.encode(q))
            }
            cmd.startsWith("search") || cmd.startsWith("google") -> {
                val q = cmd.removePrefix("search").removePrefix("google").trim().removePrefix("for").trim()
                say("Searching for $q")
                view("https://www.google.com/search?q=" + Uri.encode(q))
            }
            else -> offline(cmd)
        }
    }

    private fun view(url: String) = launch(Intent(Intent.ACTION_VIEW, Uri.parse(url)))

    private fun launch(i: Intent) {
        try { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); ctx.startActivity(i) }
        catch (e: Exception) { say("Sorry, I could not do that") }
    }

    private fun battery() {
        val b = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val l = b?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val s = b?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        say(if (l < 0) "I cannot read the battery" else "Battery is at ${l * 100 / s} percent")
    }

    private fun openApp(name: String) {
        val pm = ctx.packageManager
        val n = name.replace(" ", "")
        val hit = pm.getInstalledApplications(0).firstOrNull {
            pm.getLaunchIntentForPackage(it.packageName) != null &&
                pm.getApplicationLabel(it).toString().lowercase().replace(" ", "").contains(n)
        }
        val i = hit?.let { pm.getLaunchIntentForPackage(it.packageName) }
        if (i != null) { say("Opening $name"); launch(i) } else say("I could not find $name")
    }

    private fun numberFor(target: String): String? {
        val toks = target.split(" ").filter { it.isNotBlank() }
        val allNum = toks.isNotEmpty() && toks.all { digits.containsKey(it) || it.all(Char::isDigit) }
        if (allNum) return toks.joinToString("") { digits[it] ?: it }
        return try {
            ctx.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?",
                arrayOf("%$target%"), null
            )?.use { if (it.moveToFirst()) it.getString(0) else null }
        } catch (e: SecurityException) { null }
    }

    private fun call(target: String) {
        val n = numberFor(target)
        if (n == null) { say("I could not find $target in your contacts"); return }
        say("Calling $target")
        launch(Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(n))))
    }

    private fun message(cmd: String) {
        val rest = cmd.replace(Regex("^send\\s+(a\\s+)?"), "")
            .replace(Regex("^(message|text|whatsapp)\\s+(to\\s+)?"), "")
        val m = Regex("^(.+?)\\s+(?:saying|say|that)\\s+(.+)$").find(rest)
        val target = m?.groupValues?.get(1) ?: rest
        val body = m?.groupValues?.get(2) ?: ""
        var n = numberFor(target)
        if (n == null) { say("I could not find $target in your contacts"); return }
        n = n.replace(Regex("[^\\d]"), "")
        if (n.startsWith("0")) n = Prefs.countryCode(ctx) + n.substring(1)
        say(if (body.isEmpty()) "Opening chat with $target" else "Sending message to $target")
        if (body.isNotEmpty()) JarvisAccessibility.sendUntil = System.currentTimeMillis() + 15000
        view("https://wa.me/$n" + if (body.isNotEmpty()) "?text=" + Uri.encode(body) else "")
    }

    private fun offline(cmd: String) {
        val words = cmd.split(" ").filter { it.length > 2 }
        val best = Prefs.notes(ctx).maxByOrNull { n -> words.count { n.lowercase().contains(it) } }
        if (best != null && words.any { best.lowercase().contains(it) }) { say(best); return }
        say("I do not know that offline. Searching Google")
        view("https://www.google.com/search?q=" + Uri.encode(cmd))
    }
}
