package com.junaid.jarvis

import android.content.Context

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("jarvis", Context.MODE_PRIVATE)
    fun enabled(c: Context) = sp(c).getBoolean("on", false)
    fun setEnabled(c: Context, v: Boolean) = sp(c).edit().putBoolean("on", v).apply()
    fun notes(c: Context): MutableList<String> =
        (sp(c).getString("notes", "") ?: "").split("\n").filter { it.isNotBlank() }.toMutableList()
    fun addNote(c: Context, n: String) {
        val l = notes(c); l.add(n)
        sp(c).edit().putString("notes", l.joinToString("\n")).apply()
    }
    // Pakistan = 92. Badalna ho to yahan change karein.
    fun countryCode(c: Context) = sp(c).getString("cc", "92") ?: "92"
}
