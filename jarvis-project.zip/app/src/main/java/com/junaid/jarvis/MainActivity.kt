package com.junaid.jarvis

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var status: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 60, 40, 40) }
        fun btn(t: String, f: () -> Unit) {
            root.addView(Button(this).apply { text = t; setOnClickListener { f() } })
        }
        root.addView(TextView(this).apply { text = "JARVIS"; textSize = 30f })
        status = TextView(this).apply { textSize = 16f; setPadding(0, 20, 0, 20) }
        root.addView(status)
        btn("1. Mic, call, contacts permission") {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE,
                Manifest.permission.READ_CONTACTS), 1)
        }
        btn("2. Display over other apps") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        btn("3. Accessibility: Jarvis ko ON karein") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        btn("4. Battery: Jarvis ko restrict na karein") {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
        }
        btn("5. START JARVIS") {
            Prefs.setEnabled(this@MainActivity, true)
            startForegroundService(Intent(this@MainActivity, JarvisService::class.java))
            refresh()
        }
        btn("Stop Jarvis") {
            Prefs.setEnabled(this@MainActivity, false)
            stopService(Intent(this@MainActivity, JarvisService::class.java))
            refresh()
        }
        root.addView(TextView(this).apply {
            textSize = 14f; setPadding(0, 30, 0, 0)
            text = "Misal:\n- Jarvis open YouTube\n- Jarvis search for best laptop\n- Jarvis call Ali\n" +
                "- Jarvis message Ali saying I am coming\n- Jarvis what time is it\n" +
                "- Jarvis remember my car service is on 15th\n- Jarvis what do you remember"
        })
        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun ok(b: Boolean) = if (b) "OK" else "NAHI"

    private fun refresh() {
        val mic = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        val call = checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
        val con = checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED
        val ov = Settings.canDrawOverlays(this)
        val acc = (Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: "")
            .contains(packageName)
        status.text = "Mic: ${ok(mic)}  Call: ${ok(call)}  Contacts: ${ok(con)}\n" +
            "Overlay: ${ok(ov)}  Accessibility: ${ok(acc)}\n" +
            "Jarvis: " + if (Prefs.enabled(this)) "ON (restart ke baad bhi chalega)" else "OFF"
    }
}
