package com.junaid.jarvis

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class JarvisAccessibility : AccessibilityService() {
    companion object {
        @Volatile var sendUntil = 0L
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (System.currentTimeMillis() > sendUntil) return
        val root = rootInActiveWindow ?: return
        var t: AccessibilityNodeInfo? = null
        for (id in listOf("com.whatsapp:id/send", "com.whatsapp.w4b:id/send")) {
            t = root.findAccessibilityNodeInfosByViewId(id).firstOrNull()
            if (t != null) break
        }
        if (t == null) t = findByDesc(root, "send")
        if (t != null) {
            t.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            sendUntil = 0L
        }
    }

    private fun findByDesc(n: AccessibilityNodeInfo?, d: String): AccessibilityNodeInfo? {
        if (n == null) return null
        if (n.contentDescription?.toString()?.equals(d, true) == true) return n
        for (i in 0 until n.childCount) {
            val r = findByDesc(n.getChild(i), d)
            if (r != null) return r
        }
        return null
    }

    override fun onInterrupt() {}
}
